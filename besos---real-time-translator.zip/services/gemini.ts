import { GoogleGenAI, Type } from "@google/genai";
import { TranslationResponse, Language } from "../types";

// Initialize Gemini Client
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Translates audio input.
 */
export const translateAudioContent = async (
  audioBase64: string,
  sourceLang: Language
): Promise<TranslationResponse> => {
  const targetLang = sourceLang === 'english' ? 'Spanish' : 'English';
  const sourceLangName = sourceLang === 'english' ? 'English' : 'Spanish';

  const prompt = `
    You are an expert real-time translator facilitating a conversation between an English speaker and a Spanish speaker.
    
    The attached audio is spoken in ${sourceLangName}.
    
    Your task:
    1. Transcribe the audio exactly as spoken.
    2. Translate the transcription into natural, conversational ${targetLang}.
    
    Return the result in JSON format.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: 'audio/wav', 
              data: audioBase64
            }
          },
          { text: prompt }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            transcription: { type: Type.STRING },
            translation: { type: Type.STRING }
          },
          required: ["transcription", "translation"]
        }
      }
    });

    if (response.text) {
      return JSON.parse(response.text) as TranslationResponse;
    }
    throw new Error("No response text generated");
  } catch (error) {
    console.error("Translation error:", error);
    throw error;
  }
};

/**
 * Translates text input.
 */
export const translateText = async (
  text: string,
  sourceLang: Language
): Promise<TranslationResponse> => {
  const targetLang = sourceLang === 'english' ? 'Spanish' : 'English';
  const sourceLangName = sourceLang === 'english' ? 'English' : 'Spanish';

  const prompt = `
    You are an expert real-time translator facilitating a conversation between an English speaker and a Spanish speaker.
    
    The user has typed the following message in ${sourceLangName}: "${text}".
    
    Your task:
    1. Return the original text as the 'transcription'.
    2. Translate the text into natural, conversational ${targetLang}.
    
    Return the result in JSON format.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: { parts: [{ text: prompt }] },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            transcription: { type: Type.STRING },
            translation: { type: Type.STRING }
          },
          required: ["transcription", "translation"]
        }
      }
    });

    if (response.text) {
      return JSON.parse(response.text) as TranslationResponse;
    }
    throw new Error("No response text generated");
  } catch (error) {
    console.error("Text translation error:", error);
    throw error;
  }
};